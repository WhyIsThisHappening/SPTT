﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using MoreLinq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class USER_TableController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: USER_Table
        public ActionResult Index()
        {
                var uSERs = db.USERs.Include(u => u.AspNetUser).Include(u => u.GROUP).Include(u => u.Project).Include(u => u.ROLE);
                return View(uSERs.ToList());
        }

        // GET: USER_Table/Details/5
        public ActionResult Details(int? id)
        {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                USER uSER = db.USERs.Find(id);
                if (uSER == null)
                {
                    return HttpNotFound();
                }
                return View(uSER);
        }

        // GET: USER_Table/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email");
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name");
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName");
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name");
                return View();
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: USER_Table/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "user_id,first_name,last_name,role_id,group_id,Id,project_id")] USER uSER)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.USERs.Add(uSER);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email", uSER.Id);
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name", uSER.group_id);
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName", uSER.project_id);
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name", uSER.role_id);
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USER_Table/Edit/5
        public ActionResult Edit(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                USER uSER = db.USERs.Find(id);
                if (uSER == null)
                {
                    return HttpNotFound();
                }
                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email", uSER.Id);
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name", uSER.group_id);
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName", uSER.project_id);
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name", uSER.role_id);
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: USER_Table/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "user_id,first_name,last_name,role_id,group_id,Id,project_id")] USER uSER)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Entry(uSER).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email", uSER.Id);
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name", uSER.group_id);
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName", uSER.project_id);
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name", uSER.role_id);
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USER_Table/Delete/5
        public ActionResult Delete(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                USER uSER = db.USERs.Find(id);
                if (uSER == null)
                {
                    return HttpNotFound();
                }
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: USER_Table/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
                USER uSER = db.USERs.Find(id);
                db.USERs.Remove(uSER);
                db.SaveChanges();
                return RedirectToAction("Index");
        }
        //GET: /USER_Table/GetUserTableData
        public ActionResult GetUserTableData()
        {
                db.Configuration.ProxyCreationEnabled = false;//used to avoid problem with serialization creating an infinite loop 
            var userTableData = (from user in db.USERs
                                 join @group in db.GROUPs on user.group_id equals @group.group_id
                                 join semester in db.Semesters on @group.Semester_ID equals semester.ID
                                 join project in db.Projects on user.project_id equals project.Id
                                 join aspUser in db.AspNetUsers on user.Id equals aspUser.Id
                                 join log in db.TIME_CLOCK_EVENT_LOG on user.user_id equals log.user_id

                                 select new
                                 {
                                     user.user_id,
                                     user.first_name,
                                     user.last_name,
                                     @group.group_name,
                                     semester.Semester_Year,
                                     project.ProjectName,
                                     totalHours = 0
                                 }).DistinctBy(u => u.user_id).ToList(); //Needs moreLinq installed

            return Json(new { data = userTableData.ToList() }, JsonRequestBehavior.AllowGet);         
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
