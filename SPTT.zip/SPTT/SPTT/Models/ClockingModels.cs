﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SPTT.Models
{
    public class ClockingModels
    {
        int userID;
        int length;
        
        TestDataSetTableAdapters.TIME_CLOCK_EVENT_LOGTableAdapter clock = new TestDataSetTableAdapters.TIME_CLOCK_EVENT_LOGTableAdapter();
        TestDataSetTableAdapters.USERTableAdapter user = new TestDataSetTableAdapters.USERTableAdapter();
        TestDataSetTableAdapters.GROUPTableAdapter groupdata = new TestDataSetTableAdapters.GROUPTableAdapter();
        TestDataSet.USERDataTable userTable = new TestDataSet.USERDataTable();
       // TestDataSet.TIME_CLOCK_EVENT_LOGDataTable timeTable = new TestDataSet.TIME_CLOCK_EVENT_LOGDataTable();
        
        public void clockIn(string userIn) {


            getUserId(userIn);

           clock.ClockIn(userID,true,null,TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow,TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time")));
        }


        public void clockOut(string userIn, string comment) {
            getUserId(userIn);
          var  timeTable = clock.GetLastLogin(userID);
            length = timeTable.Rows.Count - 1;
            int lastEvent=(int)timeTable[length]["event_id"];
            clock.ClockOut(false, TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("Mountain Standard Time")), comment,false,lastEvent);
        }
        public String calcTotalUserTime(string userIn) {
            TimeSpan totalTime= TimeSpan.Zero;
            getUserId(userIn);
          var  timeTable = clock.GetTimeForCalc(userID);
            for (int i=0;i<timeTable.Rows.Count;i++) {
                DateTime clockIn= (DateTime)timeTable[i]["time_stamp_in"];
                DateTime clockOut = (DateTime)timeTable[i]["time_stamp_out"];
                TimeSpan timeWorked= clockOut - clockIn;
                totalTime +=  timeWorked;
            }

            return totalTime.ToString(@"hh\:mm"); 


        }

        public TimeSpan calcTotalUserTimeTimeSpan(string userIn2)
        {
            TimeSpan totalTime = TimeSpan.Zero;
            getUserId(userIn2);
            var timeTable = clock.GetTimeForCalc(userID);
            for (int i = 0; i < timeTable.Rows.Count; i++)
            {
                DateTime clockIn = (DateTime)timeTable[i]["time_stamp_in"];
                DateTime clockOut = (DateTime)timeTable[i]["time_stamp_out"];
                TimeSpan timeWorked = clockOut - clockIn;
                totalTime += timeWorked;
            }

            return totalTime;


        }

        public List<TestDataSet.TIME_CLOCK_EVENT_LOGRow> getTableData(string userIn) {
            TimeSpan totalTime = TimeSpan.Zero;
            getUserId(userIn);
           var  timeTable = clock.GetTimeForCalc(userID);
            var tabledata = timeTable.ToList();
            return tabledata;

        }

        public string GetUsersGroup(string userIn) {
            var group = user.GetUsersGroup(userIn);
            int length = group.Rows.Count-1;
            return group[length]["group_id"].ToString();

        }
        public string GetGroupName(byte GroupIn)
        {
            var group = groupdata.GetGroupName(GroupIn);
            int length = group.Rows.Count - 1;
            return group[length]["group_name"].ToString();

        }
        public List<TestDataSet.USERRow> GetGroupsUsers(string groupId) {

          return user.GetAllUsersInGroup(Convert.ToByte(groupId)).ToList();

        }

        public List<TestDataSet.TIME_CLOCK_EVENT_LOGRow> getAllLogs()
        {
            return clock.GetAllClockEventLogs().ToList();
        }

        public List<TestDataSet.GROUPRow> getAllGroups()
        {
            return groupdata.GetAllGroups().ToList();
        }
        public List<TestDataSet.USERRow> getAllUserData()
        {
            return user.GetData().ToList();
        }
        public List<TestDataSet.USERRow> getAllUsers()
        {
            return user.GetAllUsers().ToList();
        }

        public List<TestDataSet.USERRow> getAllUsersByGroup(byte idIn)
        {
            return user.GetAllUsersInGroup(idIn).ToList();
        }

        private void getUserId(string userIn) {

            userTable = user.GetId(userIn);
            length = userTable.Rows.Count - 1;
            userID = (int)userTable[length]["user_id"];

        }

       public void UserUpdateEvent(string id, string clockIn,string clockout, string comment ) {
            

            clock.UpdateEntry(DateTime.Parse(clockIn),DateTime.Parse(clockout),comment,true,Convert.ToInt32(id));

        }

    }
 
    
}