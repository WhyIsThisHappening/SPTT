﻿using SPTT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using System.Collections.Specialized;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SPTT.Controllers
{
    public class DataController : ApiController
    {
        public IEnumerable<object> Get()
        {
            Console.WriteLine("STATS CALL :: Get");
            StatsModel model = new StatsModel();

            var records = model.TimeEntries;
            List<LogEntry> entries = new List<LogEntry>();
            
            foreach(var item in records)
            {
                entries.Add(new LogEntry(item.ItemArray[8].ToString(), item.ItemArray[9].ToString(), 
                    item.comment, item.is_modified, 
                    item.time_stamp_in, item.time_stamp_out, item.event_id));
            }

            return entries;
        }

        public void Put(int id, [FromBody]LogEntry item)
        {
            if (ActionContext.ModelState.IsValid)
            {
                if(item != null)
                {
                    var _db = new TestDataSetTableAdapters.TIME_CLOCK_EVENT_LOGTableAdapter();
                    _db.UpdateEntry(item.inTime, item.outTime, item.comment,item.modified,id);
                }
            }
            else
            {
                //return Request.CreateErrorResponse(HttpStatusCode.BadRequest, new Exception("Model isn't valid."));
            }

            //return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
