﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class TIME_CLOCK_EVENT_LOGController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: TIME_CLOCK_EVENT_LOG
        public ActionResult Index()
        {
            if (User.IsInRole("admin"))
            {
                var tIME_CLOCK_EVENT_LOG = db.TIME_CLOCK_EVENT_LOG.Include(t => t.USER).Include(t => t.WORK_TYPE);
                return View(tIME_CLOCK_EVENT_LOG.ToList());
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: TIME_CLOCK_EVENT_LOG/Details/5
        public ActionResult Details(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                TIME_CLOCK_EVENT_LOG tIME_CLOCK_EVENT_LOG = db.TIME_CLOCK_EVENT_LOG.Find(id);
                if (tIME_CLOCK_EVENT_LOG == null)
                {
                    return HttpNotFound();
                }
                return View(tIME_CLOCK_EVENT_LOG);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: TIME_CLOCK_EVENT_LOG/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                ViewBag.user_id = new SelectList(db.USERs, "user_id", "first_name");
                ViewBag.work_type_id = new SelectList(db.WORK_TYPE, "work_type_id", "work_type1");
                return View();
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: TIME_CLOCK_EVENT_LOG/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "event_id,user_id,is_clocked_in,work_type_id,time_stamp_in,time_stamp_out,comment,is_modified")] TIME_CLOCK_EVENT_LOG tIME_CLOCK_EVENT_LOG)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.TIME_CLOCK_EVENT_LOG.Add(tIME_CLOCK_EVENT_LOG);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.user_id = new SelectList(db.USERs, "user_id", "first_name", tIME_CLOCK_EVENT_LOG.user_id);
                ViewBag.work_type_id = new SelectList(db.WORK_TYPE, "work_type_id", "work_type1", tIME_CLOCK_EVENT_LOG.work_type_id);
                return View(tIME_CLOCK_EVENT_LOG);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: TIME_CLOCK_EVENT_LOG/Edit/5
        public ActionResult Edit(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                TIME_CLOCK_EVENT_LOG tIME_CLOCK_EVENT_LOG = db.TIME_CLOCK_EVENT_LOG.Find(id);
                if (tIME_CLOCK_EVENT_LOG == null)
                {
                    return HttpNotFound();
                }
                ViewBag.user_id = new SelectList(db.USERs, "user_id", "first_name", tIME_CLOCK_EVENT_LOG.user_id);
                ViewBag.work_type_id = new SelectList(db.WORK_TYPE, "work_type_id", "work_type1", tIME_CLOCK_EVENT_LOG.work_type_id);
                return View(tIME_CLOCK_EVENT_LOG);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: TIME_CLOCK_EVENT_LOG/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "event_id,user_id,is_clocked_in,work_type_id,time_stamp_in,time_stamp_out,comment,is_modified")] TIME_CLOCK_EVENT_LOG tIME_CLOCK_EVENT_LOG)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Entry(tIME_CLOCK_EVENT_LOG).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.user_id = new SelectList(db.USERs, "user_id", "first_name", tIME_CLOCK_EVENT_LOG.user_id);
                ViewBag.work_type_id = new SelectList(db.WORK_TYPE, "work_type_id", "work_type1", tIME_CLOCK_EVENT_LOG.work_type_id);
                return View(tIME_CLOCK_EVENT_LOG);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: TIME_CLOCK_EVENT_LOG/Delete/5
        public ActionResult Delete(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                TIME_CLOCK_EVENT_LOG tIME_CLOCK_EVENT_LOG = db.TIME_CLOCK_EVENT_LOG.Find(id);
                if (tIME_CLOCK_EVENT_LOG == null)
                {
                    return HttpNotFound();
                }
                return View(tIME_CLOCK_EVENT_LOG);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: TIME_CLOCK_EVENT_LOG/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (User.IsInRole("admin"))
            {
                TIME_CLOCK_EVENT_LOG tIME_CLOCK_EVENT_LOG = db.TIME_CLOCK_EVENT_LOG.Find(id);
                db.TIME_CLOCK_EVENT_LOG.Remove(tIME_CLOCK_EVENT_LOG);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else

                return RedirectToAction("Login", "Account");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
