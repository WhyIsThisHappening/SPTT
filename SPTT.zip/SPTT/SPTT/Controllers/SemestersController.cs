﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class SemestersController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: Semesters
        public ActionResult Index()
        {
            if (User.IsInRole("admin"))
            {
                return View(db.Semesters.ToList());
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: Semesters/Details/5
        public ActionResult Details(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Semester semester = db.Semesters.Find(id);
                if (semester == null)
                {
                    return HttpNotFound();
                }
                return View(semester);

            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: Semesters/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                return View();
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: Semesters/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Semester_Year")] Semester semester)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Semesters.Add(semester);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(semester);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: Semesters/Edit/5
        public ActionResult Edit(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Semester semester = db.Semesters.Find(id);
                if (semester == null)
                {
                    return HttpNotFound();
                }
                return View(semester);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: Semesters/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Semester_Year")] Semester semester)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Entry(semester).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(semester);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: Semesters/Delete/5
        public ActionResult Delete(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Semester semester = db.Semesters.Find(id);
                if (semester == null)
                {
                    return HttpNotFound();
                }
                return View(semester);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: Semesters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (User.IsInRole("admin"))
            {
                Semester semester = db.Semesters.Find(id);
                db.Semesters.Remove(semester);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else

                return RedirectToAction("Login", "Account");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
