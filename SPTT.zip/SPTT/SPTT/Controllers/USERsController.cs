﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class USERsController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: USERs
        public ActionResult Index()
        {
            if (User.IsInRole("admin"))
            {
                var uSERs = db.USERs.Include(u => u.AspNetUser).Include(u => u.GROUP).Include(u => u.Project).Include(u => u.ROLE);
                return View(uSERs.ToList());
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USERs/Details/5
        public ActionResult Details(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                USER uSER = db.USERs.Find(id);
                if (uSER == null)
                {
                    return HttpNotFound();
                }
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USERs/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email");
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name");
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName");
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name");
                return View();
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: USERs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "user_id,first_name,last_name,role_id,group_id,Id,project_id")] USER uSER)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.USERs.Add(uSER);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email", uSER.Id);
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name", uSER.group_id);
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName", uSER.project_id);
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name", uSER.role_id);
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USERs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                USER uSER = db.USERs.Find(id);
                if (uSER == null)
                {
                    return HttpNotFound();
                }
                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email", uSER.Id);
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name", uSER.group_id);
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName", uSER.project_id);
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name", uSER.role_id);
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: USERs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "user_id,first_name,last_name,role_id,group_id,Id,project_id")] USER uSER)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Entry(uSER).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.Id = new SelectList(db.AspNetUsers, "Id", "Email", uSER.Id);
                ViewBag.group_id = new SelectList(db.GROUPs, "group_id", "group_name", uSER.group_id);
                ViewBag.project_id = new SelectList(db.Projects, "Id", "ProjectName", uSER.project_id);
                ViewBag.role_id = new SelectList(db.ROLEs, "role_id", "role_name", uSER.role_id);
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USERs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                USER uSER = db.USERs.Find(id);
                if (uSER == null)
                {
                    return HttpNotFound();
                }
                return View(uSER);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: USERs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (User.IsInRole("admin"))
            {
                USER uSER = db.USERs.Find(id);
                db.USERs.Remove(uSER);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: USERs/GetUserData
        public ActionResult GetUserData()
        {
            if (User.IsInRole("admin"))
            {
                db.Configuration.ProxyCreationEnabled = false;//used to avoid problem with serialization creating an infinite loop 
                var userData = db.USERs.OrderBy(u => u.user_id).ToList();
                return Json(new { data = userData }, JsonRequestBehavior.AllowGet);
            }
            else

                return RedirectToAction("Login", "Account");
            
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
