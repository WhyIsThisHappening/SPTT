﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;

namespace SPTT.Models
{

    public class StatsModel
    {
        public List<TestDataSet.USERRow> Users { get; set; }
        public List<TestDataSet.TIME_CLOCK_EVENT_LOGRow> TimeEntries {get; set;}
        public List<TestDataSet.GROUPRow> Groups { get; set; }

        public StatsModel()
        {
            //Create table adapters
            TestDataSetTableAdapters.USERTableAdapter usersTable = new TestDataSetTableAdapters.USERTableAdapter();
            TestDataSetTableAdapters.TIME_CLOCK_EVENT_LOGTableAdapter entriesTable = new TestDataSetTableAdapters.TIME_CLOCK_EVENT_LOGTableAdapter();
            TestDataSetTableAdapters.GROUPTableAdapter groupsTable = new TestDataSetTableAdapters.GROUPTableAdapter();

            //Fill attributes
            Users = usersTable.GetAllUsers().ToList();
            TimeEntries = entriesTable.GetAllClockEventLogs().ToList();
            //Groups = groupsTable.GetAllGroups().ToList();

        }
    }
}