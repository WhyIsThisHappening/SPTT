﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;

namespace SPTT.Models
{
    public class IndexViewModel
    {


        public bool HasPassword { get; set; }
        public IList<UserLoginInfo> Logins { get; set; }
        public string PhoneNumber { get; set; }
        public bool TwoFactor { get; set; }
        public bool BrowserRemembered { get; set; }
        public string group { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phoneNumber { get; set; }
        public string project { get; set; }
        int length;
        TestDataSetTableAdapters.USERTableAdapter user = new TestDataSetTableAdapters.USERTableAdapter();
        TestDataSet.USERDataTable userTable = new TestDataSet.USERDataTable();
        TestDataSetTableAdapters.ProjectTableAdapter projects = new TestDataSetTableAdapters.ProjectTableAdapter();
        public void GetGroup(string UserIn)
        {
            try
            {
                var newTable = user.GetUsersGroup(UserIn);
                length = newTable.Rows.Count - 1;
                group = (string)newTable[length]["group_name"];
                firstName = (string)newTable[length]["first_name"];
                lastName = (string)newTable[length]["last_name"];
            }
            catch
            {
                group = null;
                firstName = "John";
                lastName = "Doe";
            }
        }

        public void getProject(string UserIn)
        {
            try
            {
                var newTable = user.GetProject(UserIn);
                length = newTable.Rows.Count - 1;
                project = (string)newTable[length]["ProjectName"];
            }
            catch
            {
                project = "No project selected";
            }
        }

    }

    public class ManageLoginsViewModel
    {
        public IList<UserLoginInfo> CurrentLogins { get; set; }
        public IList<AuthenticationDescription> OtherLogins { get; set; }
    }





    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }

    public class SetPasswordViewModel
    {
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class ChangeGroupViewModel
    {
        TestDataSetTableAdapters.USERTableAdapter user = new TestDataSetTableAdapters.USERTableAdapter();
        TestDataSet.USERDataTable userTable = new TestDataSet.USERDataTable();
        TestDataSetTableAdapters.GROUPTableAdapter group = new TestDataSetTableAdapters.GROUPTableAdapter();
        TestDataSetTableAdapters.ProjectTableAdapter projects = new TestDataSetTableAdapters.ProjectTableAdapter();

        public List<string> Groups { get; set; }
        public List<string> Projects { get; set; }
        public string MenuSelection { get; set; }
        public System.Web.Mvc.SelectList listItems { get; set; }
        public System.Web.Mvc.SelectList projectListItems { get; set; }
        public void getGroups()
        {

            var groupsIn = group.GetAllGroups();
            var projectIn = projects.GetProjectsbyActiveorInactive(true);
            List<string> grouplist = new List<string>();
            List<string> projectList = new List<string>();
            foreach (var item in groupsIn)
            {
                grouplist.Add(item.group_name);
            }

            foreach (var project in projectIn)
            {
                projectList.Add(project.ProjectName);

            }
            Groups = grouplist;
            Projects = projectList;


        }


        public void makeList()
        {
            listItems = new System.Web.Mvc.SelectList(Groups);
            projectListItems = new System.Web.Mvc.SelectList(Projects);
        }
    }


    public class UpdateUsersGroup
    {

        TestDataSetTableAdapters.GROUPTableAdapter group = new TestDataSetTableAdapters.GROUPTableAdapter();
        TestDataSetTableAdapters.USERTableAdapter user = new TestDataSetTableAdapters.USERTableAdapter();
        TestDataSetTableAdapters.ProjectTableAdapter project = new TestDataSetTableAdapters.ProjectTableAdapter();

        public void updateTheGroup(string UpdateProject,string UpdateGroup, string userId)
        {
            var groupid = group.getGroupId(UpdateGroup);
            int length = groupid.Rows.Count - 1;
            user.UpdateGroupID((byte)groupid[length]["group_id"], userId);

            var projectid = project.GetProjectID(UpdateProject);
            length = projectid.Rows.Count - 1;
            user.UpdateProject((int)projectid[length]["Id"],userId);


        }
    }

    public class ProjectsViewModel
    {

        TestDataSetTableAdapters.ProjectTableAdapter group = new TestDataSetTableAdapters.ProjectTableAdapter();
        TestDataSetTableAdapters.USERTableAdapter user = new TestDataSetTableAdapters.USERTableAdapter();

        public void GetUserProject(string UpdateGroup, string userId)
        {
            // var groupid = group.getGroupId(UpdateGroup);
            // int length = groupid.Rows.Count - 1;

            //  user.UpdateGroupID((byte)groupid[length]["group_id"], userId);

        }
    }

    public class CreateGroupViewModel
    {
        public string newGroup { get; set; }

        TestDataSetTableAdapters.GROUPTableAdapter group = new TestDataSetTableAdapters.GROUPTableAdapter();
        public void CreateGroup(string newGroup)
        {
            group.InsertQuery(newGroup);

        }


    }

    public class ChangeNameViewModel
    {

        TestDataSetTableAdapters.USERTableAdapter user = new TestDataSetTableAdapters.USERTableAdapter();
        public string firstName { get; set; }
        public string lastName { get; set; }


        public void UpdateNames(string firstName, string lastName, string userId)
        {

            if (@firstName != null)
            {
                user.UpdateFirst(@firstName, userId);
            }
            if (@lastName != null)
            {
                user.UpdateLast(@lastName, userId);
            }
        }

    }



    public class ChangePasswordViewModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class AddPhoneNumberViewModel
    {
        [Required]
        [Phone]
        [Display(Name = "Phone Number")]
        public string Number { get; set; }
    }

    public class VerifyPhoneNumberViewModel
    {
        [Required]
        [Display(Name = "Code")]
        public string Code { get; set; }

        [Required]
        [Phone]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }
    }

    public class ConfigureTwoFactorViewModel
    {
        public string SelectedProvider { get; set; }
        public ICollection<System.Web.Mvc.SelectListItem> Providers { get; set; }
    }
}