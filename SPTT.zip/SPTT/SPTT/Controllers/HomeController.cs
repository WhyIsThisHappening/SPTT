﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Helpers;
using SPTT.Models;
using Microsoft.AspNet.Identity;
using System.Web.UI.DataVisualization.Charting;
using System.IO;
using System.Drawing;
namespace SPTT.Controllers
{
    public class HomeController : Controller
    {
        HomeModel model = new HomeModel();
        ClockingModels clock = new ClockingModels();
        

        public ActionResult Index()
        {
            if (User.Identity.IsAuthenticated)
            {
                getUser();
                model.TotalUserTime = clock.calcTotalUserTime(model.userID);
                model.ClockInBtn = "enabled";
                model.ClockOutBtn = "disabled";
                model.SubmitBtn = "disabled";
                model.TableData = clock.getTableData(model.userID);
                MakesClassCharts();
                MakesGroupCharts();
                return View(model);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        public ActionResult Setup()
        {
            if (User.IsInRole("admin"))
            {
                ViewBag.Message = "Admin Dashboard";

                return View();
            }
            else {
                return RedirectToAction("Login", "Account");
            }
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Stats()
        {
            model.TableData = clock.getAllLogs();
            ViewBag.Users = clock.getAllUsers();

            return View(model);
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }


        //GetComment Action after submitting from the text box, the get comment action set the totalUserTime in the home model, sets the Comment value to text box
        //disables the clock in button, enabled the clock out button and returns the GetComment view with model data.
        [HttpPost]
        public ActionResult GetComment(string txtCommentBox)
        {
            if (User.Identity.IsAuthenticated)
            {
                getUser();
                model.TotalUserTime = clock.calcTotalUserTime(model.userID);
                model.Comment = txtCommentBox;
                model.ClockInBtn = "disabled";
                model.ClockOutBtn = "enabled";
                model.SubmitBtn = "disabled";
                model.TableData = clock.getTableData(model.userID);
                MakesClassCharts();
                MakesGroupCharts();
                return View(model);
            }
            else

                return RedirectToAction("Login", "Account");
        }
        //Clockin Action checks if the user is logged in (if not send to login view/account controller). Sets total user time in model, Sets the clock in button to disable,
        //Sets clockout button to disable, sends the userID to the clockIn model method. Updates to ClockIn view.  -11/8/17 BB
        [HttpPost]
        public ActionResult ClockIn()
        {
            if (User.Identity.IsAuthenticated)
            {
                getUser();
                model.TotalUserTime = clock.calcTotalUserTime(model.userID);
                model.ClockInBtn = "disabled";
                model.ClockOutBtn = "disabled";
                model.SubmitBtn = "disabled";
                clock.clockIn(model.userID);
                model.TableData = clock.getTableData(model.userID);
                MakesClassCharts();
                MakesGroupCharts();
                return View(model);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        [HttpPost]
        public ActionResult UserUpdateInfo(string id,string timestampin,string timestampout, string comment)
        {

            clock.UserUpdateEvent(id,timestampin,timestampout,comment);

            return RedirectToAction("Home", "Index");
        }

        //ClockOut Action checks if the user is logged in (if not send to login view/account controller) Sets the clock in button to enable,
        //clockout button to disable, sends the userID, user comment to the clockOut model method. updates the total user time in the model 
        //and then updates to Clockout View -11/8/17 BB
        [HttpPost]
        public ActionResult ClockOut(string txtCommentBox)
        {
            if (User.Identity.IsAuthenticated)
            {
                getUser();
                model.ClockInBtn = "enabled";
                model.ClockOutBtn = "disabled";
                model.SubmitBtn = "disabled";

                clock.clockOut(model.userID, txtCommentBox);
                //moved down so it updates time on clockout
                model.TableData = clock.getTableData(model.userID);
                model.TotalUserTime = clock.calcTotalUserTime(model.userID);
                MakesClassCharts();
                MakesGroupCharts();

                return RedirectToAction("Index", "Home");
            }
            else

                return RedirectToAction("Login", "Account");
        }

        //internal method to get the userId of current logged in user
        private void getUser()
        {
            model.userID = User.Identity.GetUserId();
            
        }


        private TimeSpan CalcTimespan(DateTime one, DateTime two) {
            TimeSpan time = new TimeSpan();
            time = TimeSpan.Zero;
            time = two - one;
            return time;

        }
        //List<int> datain, List<string>labelin
        public ActionResult MakesGroupCharts()
        {
            try
            {
                //Data Section
                getUser();
                string userGroup = clock.GetUsersGroup(model.userID);
                var users = clock.GetGroupsUsers(userGroup).ToList();
                List<string> names = new List<string>();
                List<double> timeWorked = new List<double>();
                List<string> userID = new List<string>();
                foreach (var name in users)
                {
                    names.Add(name.first_name+" "+name.last_name );
                    userID.Add(name.Id);
                }
                foreach (var user in userID)
                {
                    timeWorked.Add(Math.Truncate((clock.calcTotalUserTimeTimeSpan(user).TotalMinutes) / 60));
                }
                model.groupTimes = timeWorked;
                model.groupLabels = names;

                //Chart Section
                System.Web.UI.DataVisualization.Charting.Chart chart = new System.Web.UI.DataVisualization.Charting.Chart();
                chart.ChartAreas.Add(SetChartArea());
                chart.Width = 300;
                chart.Height =300;
                Title title = chart.Titles.Add(clock.GetGroupName(Convert.ToByte(userGroup)).ToString() + " Time by Student"+ Environment.NewLine + "(workhours)");
                title.Font= new Font("Segoe UI", 14f, FontStyle.Bold);
                title.Docking = Docking.Top;
                chart.Legends.Add(new Legend("Students"));
                chart.Series.Add(new Series("Data"));
                chart.Series["Data"].ChartType = SeriesChartType.Pie;
                chart.Series["Data"]["PieLabelStyle"] = "Outside";
                chart.Series["Data"]["PieLineColor"] = "Black";
                chart.Series["Data"].Font = new Font("Segoe UI", 12f, FontStyle.Italic);
                chart.Series["Data"].Points.DataBindXY(
                    xValue: model.groupLabels,
                    xField: "UserID",
                    yValue: model.groupTimes,
                    yFields: "Time Entry"

                    );
              
             
                chart.Series["Data"].IsValueShownAsLabel = true;
                chart.Series["Data"].Legend = "Students";

                chart.Legends["Students"].Font = new Font("Segoe UI", 10f, FontStyle.Regular);
                chart.Legends["Students"].Docking = Docking.Bottom;

                MemoryStream ms = new MemoryStream();
                chart.SaveImage(ms, ChartImageFormat.Png);
                return File(ms.ToArray(), "image/png");
            }
            catch (Exception e) {
                System.Web.UI.DataVisualization.Charting.Chart chart = new System.Web.UI.DataVisualization.Charting.Chart();
                chart.ChartAreas.Add(SetChartArea());
                chart.Width = 300;
                chart.Height = 300;
                Title title = chart.Titles.Add("You 100% haven't joined a group: See theres a pie chart!");
                title.Docking = Docking.Top;
                title.Font = new Font("Segoe UI", 14f, FontStyle.Bold);
                chart.Series.Add(new Series("Data"));
                chart.Series["Data"].ChartType = SeriesChartType.Pie;
                chart.Series["Data"]["PieLabelStyle"] = "Outside";
                chart.Series["Data"]["PieLineColor"] = "Black";
                chart.Series["Data"].Font = new Font("Segoe UI", 12f, FontStyle.Italic);
                chart.Series["Data"].Points.DataBindXY(
                    xValue: new[] { "No Group Selected"},
                    xField: "Error",
                    yValue: new[] { 1 },
                    yFields: "Error"
                    );
       
           
                MemoryStream ms = new MemoryStream();
                chart.SaveImage(ms, ChartImageFormat.Png);
                Console.WriteLine(e.Message);
                return File(ms.ToArray(), "image/png");
            }
        }
        public ActionResult MakesClassCharts()
        {
            getUser();
            
            var groups = clock.getAllGroups();
            List<string> groupNames = new List<string>();
            List<string> groupId = new List<string>();

           
            List<double> timeWorked = new List<double>();
            List<string> userID = new List<string>();

            foreach (var group in groups) {
                var usersInGroup = clock.getAllUsersByGroup(group.group_id);
                double timeWorkedByGroup = 0;
                foreach (var user in usersInGroup) {
                   timeWorkedByGroup+=(Math.Truncate(clock.calcTotalUserTimeTimeSpan(user.Id).TotalMinutes / 60));
                }
                groupNames.Add(group.group_name);
                timeWorked.Add(timeWorkedByGroup);

            }

            model.classTimes = timeWorked;
            model.classLabels = groupNames;

          

            System.Web.UI.DataVisualization.Charting.Chart chart = new System.Web.UI.DataVisualization.Charting.Chart();
            chart.ChartAreas.Add(SetChartArea());
            chart.Width = 300;
            chart.Height = 300;
           
            Title title=chart.Titles.Add("Group Time by Class" + Environment.NewLine + "(workhours)");
            title.Font = new Font("Segoe UI", 14f, FontStyle.Bold);
            title.Docking = Docking.Top;
            chart.Legends.Add (new Legend( "Students"));
            chart.Series.Add(new Series("Data"));
            chart.Series["Data"].ChartType = SeriesChartType.Pie;
            chart.Series["Data"]["PieLabelStyle"] = "Outside";
            chart.Series["Data"]["PieLineColor"] = "Black";
            chart.Series["Data"].Font = new Font("Segoe UI", 12f, FontStyle.Italic);
            chart.Series["Data"].Points.DataBindXY(
                xValue: model.classLabels,
                xField: "UserID",
                yValue: model.classTimes,
                yFields:"Time Entry"

                );

            chart.Series["Data"].IsValueShownAsLabel = true;
              chart.Series["Data"].Legend = "Students";
        
            chart.Legends["Students"].Docking = Docking.Bottom;
            chart.Legends["Students"].Font = new Font("Segoe UI", 10f, FontStyle.Regular);
            
            MemoryStream ms = new MemoryStream();
            chart.SaveImage(ms, ChartImageFormat.Png);
            return File(ms.ToArray(), "image/png");

        }
        public ActionResult MakesClassChartsStudent()
        {
            getUser();
            var users = clock.getAllUserData();
            List<string> names = new List<string>();
            List<double> timeWorked = new List<double>();
            List<string> userID = new List<string>();
            foreach (var name in users)
            {
                names.Add(name.first_name + " " + name.last_name);
                userID.Add(name.Id);
            }
            foreach (var user in userID)
            {
                // Did we mean to pull Total Minutes? Currently this will only pull the minutes of time.
                // Ex. 10 Hrs and 15 minuts worked would be 10:15
                // This code only pulls the 15 minutes
                // Perhaps we need to use totalMinutse to convert the total time into total minutes?

                //woops, fixed time calc-bb 12/4/17
                timeWorked.Add(Math.Truncate(clock.calcTotalUserTimeTimeSpan(user).TotalMinutes / 60));

            }
            model.classTimes = timeWorked;
            model.classLabels = names;



            System.Web.UI.DataVisualization.Charting.Chart chart = new System.Web.UI.DataVisualization.Charting.Chart();
            chart.ChartAreas.Add(SetChartArea());
            chart.Width = 300;
            chart.Height = 300;

            Title title = chart.Titles.Add("Class Time by Student" + Environment.NewLine + "(workhours)");
            title.Font = new Font("Segoe UI", 14f, FontStyle.Bold);
            title.Docking = Docking.Top;
            chart.Legends.Add(new Legend("Students"));
            chart.Series.Add(new Series("Data"));
            chart.Series["Data"].ChartType = SeriesChartType.Pie;
            chart.Series["Data"]["PieLabelStyle"] = "Outside";
            chart.Series["Data"]["PieLineColor"] = "Black";
            chart.Series["Data"].Font = new Font("Segoe UI", 12f, FontStyle.Italic);
            chart.Series["Data"].Points.DataBindXY(
                xValue: model.classLabels,
                xField: "UserID",
                yValue: model.classTimes,
                yFields: "Time Entry"

                );

            chart.Series["Data"].IsValueShownAsLabel = true;
            chart.Series["Data"].Legend = "Students";

            chart.Legends["Students"].Docking = Docking.Bottom;
            chart.Legends["Students"].Font = new Font("Segoe UI", 10f, FontStyle.Regular);

            MemoryStream ms = new MemoryStream();
            chart.SaveImage(ms, ChartImageFormat.Png);
            return File(ms.ToArray(), "image/png");

        }

        ChartArea SetChartArea()
        {
            System.Web.UI.DataVisualization.Charting.ChartArea chartArea1 =
                      new System.Web.UI.DataVisualization.Charting.ChartArea();
            
            chartArea1.Area3DStyle.Inclination = 45;
            chartArea1.Area3DStyle.IsClustered = true;
            chartArea1.Area3DStyle.IsRightAngleAxes = false;
            chartArea1.Area3DStyle.LightStyle =
               System.Web.UI.DataVisualization.Charting.LightStyle.Realistic;
            chartArea1.Area3DStyle.Enable3D = true;
            chartArea1.Area3DStyle.Perspective = 35;
            chartArea1.Area3DStyle.Rotation = 45;
            chartArea1.Area3DStyle.WallWidth = 20;
          
            chartArea1.AxisX.LineColor = System.Drawing.Color.Teal;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.Teal;
   
            chartArea1.AxisY.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))),
                    ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.Teal;
           chartArea1.BackColor= System.Drawing.Color.Transparent;

            chartArea1.Name = "Default";
            chartArea1.ShadowColor = System.Drawing.Color.Transparent;

            return chartArea1;
        }


    }





}