﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class AspNetUsersController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: AspNetUsers
        public ActionResult Index()
        {
            if (User.IsInRole("admin"))
            {
                return View(db.AspNetUsers.ToList());
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: AspNetUsers/Details/5
        public ActionResult Details(string id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                AspNetUser aspNetUser = db.AspNetUsers.Find(id);
                if (aspNetUser == null)
                {
                    return HttpNotFound();
                }
                return View(aspNetUser);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: AspNetUsers/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                return View();
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: AspNetUsers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AspNetUser aspNetUser)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.AspNetUsers.Add(aspNetUser);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(aspNetUser);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: AspNetUsers/Edit/5
        public ActionResult Edit(string id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                AspNetUser aspNetUser = db.AspNetUsers.Find(id);
                if (aspNetUser == null)
                {
                    return HttpNotFound();
                }
                return View(aspNetUser);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: AspNetUsers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AspNetUser aspNetUser)
        {
            if (User.IsInRole("admin"))
            {

                if (ModelState.IsValid)
                {
                    db.Entry(aspNetUser).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(aspNetUser);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: AspNetUsers/Delete/5
        public ActionResult Delete(string id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                AspNetUser aspNetUser = db.AspNetUsers.Find(id);
                if (aspNetUser == null)
                {
                    return HttpNotFound();
                }
                return View(aspNetUser);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: AspNetUsers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            if (User.IsInRole("admin"))
            {
                AspNetUser aspNetUser = db.AspNetUsers.Find(id);
                db.AspNetUsers.Remove(aspNetUser);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else

                return RedirectToAction("Login", "Account");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
