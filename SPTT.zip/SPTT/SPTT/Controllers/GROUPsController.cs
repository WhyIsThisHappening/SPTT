﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class GROUPsController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: GROUPs
        public ActionResult Index()
        {
            if (User.IsInRole("admin"))
            {
                var gROUPs = db.GROUPs.Include(g => g.Semester);
                return View(gROUPs.ToList());
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: GROUPs/Details/5
        public ActionResult Details(byte? id)
        {

            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                GROUP gROUP = db.GROUPs.Find(id);
                if (gROUP == null)
                {
                    return HttpNotFound();
                }
                return View(gROUP);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: GROUPs/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                ViewBag.Semester_ID = new SelectList(db.Semesters, "ID", "Semester_Year");
                return View();
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: GROUPs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "group_id,group_name,Semester_ID")] GROUP gROUP)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.GROUPs.Add(gROUP);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.Semester_ID = new SelectList(db.Semesters, "ID", "Semester_Year", gROUP.Semester_ID);
                return View(gROUP);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: GROUPs/Edit/5
        public ActionResult Edit(byte? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                GROUP gROUP = db.GROUPs.Find(id);
                if (gROUP == null)
                {
                    return HttpNotFound();
                }
                ViewBag.Semester_ID = new SelectList(db.Semesters, "ID", "Semester_Year", gROUP.Semester_ID);
                return View(gROUP);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: GROUPs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "group_id,group_name,Semester_ID")] GROUP gROUP)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Entry(gROUP).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.Semester_ID = new SelectList(db.Semesters, "ID", "Semester_Year", gROUP.Semester_ID);
                return View(gROUP);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // GET: GROUPs/Delete/5
        public ActionResult Delete(byte? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                GROUP gROUP = db.GROUPs.Find(id);
                if (gROUP == null)
                {
                    return HttpNotFound();
                }
                return View(gROUP);
            }
            else

                return RedirectToAction("Login", "Account");
        }

        // POST: GROUPs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(byte id)
        {
            if (User.IsInRole("admin"))
            {
                GROUP gROUP = db.GROUPs.Find(id);
                db.GROUPs.Remove(gROUP);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else

                return RedirectToAction("Login", "Account");
        }

        public ActionResult GetGroupData()
        {
            if (User.IsInRole("admin"))
            {
              
                    db.Configuration.ProxyCreationEnabled = false;//used to avoid problem with serialization creating an infinite loop 
                    var groupData = db.GROUPs.OrderBy(g => g.group_id).ToList();
                    return Json(new { data = groupData }, JsonRequestBehavior.AllowGet);
                
            }
            else

                return RedirectToAction("Login", "Account");
            
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
