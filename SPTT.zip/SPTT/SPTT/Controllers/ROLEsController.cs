﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SPTT.Models;

namespace SPTT.Controllers
{
    public class ROLEsController : Controller
    {
        private DBTestEntities db = new DBTestEntities();

        // GET: ROLEs
        public ActionResult Index()
        {
            if (User.IsInRole("admin"))
            {
                return View(db.ROLEs.ToList());
            }
            else
               {
                return RedirectToAction("Login", "Account");
            }
        }

        // GET: ROLEs/Details/5
        public ActionResult Details(byte? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                ROLE rOLE = db.ROLEs.Find(id);
                if (rOLE == null)
                {
                    return HttpNotFound();
                }
                return View(rOLE);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        // GET: ROLEs/Create
        public ActionResult Create()
        {
            if (User.IsInRole("admin"))
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        // POST: ROLEs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "role_id,role_name")] ROLE rOLE)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.ROLEs.Add(rOLE);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(rOLE);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        // GET: ROLEs/Edit/5
        public ActionResult Edit(byte? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                ROLE rOLE = db.ROLEs.Find(id);

                if (rOLE == null)
                {
                    return HttpNotFound();
                }
                return View(rOLE);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        // POST: ROLEs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "role_id,role_name")] ROLE rOLE)
        {
            if (User.IsInRole("admin"))
            {
                if (ModelState.IsValid)
                {
                    db.Entry(rOLE).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(rOLE);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        // GET: ROLEs/Delete/5
        public ActionResult Delete(byte? id)
        {
            if (User.IsInRole("admin"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                ROLE rOLE = db.ROLEs.Find(id);
                if (rOLE == null)
                {
                    return HttpNotFound();
                }
                return View(rOLE);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        // POST: ROLEs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(byte id)
        {
            if (User.IsInRole("admin"))
            {
                ROLE rOLE = db.ROLEs.Find(id);
                db.ROLEs.Remove(rOLE);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
