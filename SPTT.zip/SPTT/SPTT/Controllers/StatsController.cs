﻿using SPTT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SPTT.Controllers
{
    public class StatsController : Controller
    {
        [HttpPost]
        public ActionResult Stats(string groupID = "", string userID = "")
        {
            //Fill model tables
            StatsModel model = new StatsModel();
            return View(model);
        }

        // GET: Stats
        [HttpGet]
        public ActionResult Stats()
        {
            //Fill model tables
            StatsModel model = new StatsModel();
            return View(model);
        }

    }
}