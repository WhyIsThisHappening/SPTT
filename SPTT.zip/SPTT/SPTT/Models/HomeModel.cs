﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using System.ComponentModel.DataAnnotations;
namespace SPTT.Models
{
    public class HomeModel
    {
        public string condStyle { get; set; }
        public string userID { get; set; }
        public string ClockInBtn { get; set; }
        public string ClockOutBtn { get; set; }
        public string SubmitBtn { get; set; }
        public string Comment { get; set; }
        public string CommentLabel { get; set; }
        public string TotalUserTime { get; set; }
        public List<double> classTimes { get; set; }
        public List<string> classLabels { get; set; }
        public List<double> groupTimes { get; set; }
        public List<string> groupLabels { get; set; }
        public List<TestDataSet.TIME_CLOCK_EVENT_LOGRow> TableData { get; set; }
        public byte[] GroupChart { get; set; }
    }
    
}

public class StudentModel
{
    public string time_stamp_in { get; set; }
    public string time_stamp_out { get; set; }
    public string comment{ get; set; }
    public string is_modified { get; set; }
 
}
    
